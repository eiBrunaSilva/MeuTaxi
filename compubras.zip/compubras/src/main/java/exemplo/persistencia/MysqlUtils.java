package exemplo.persistencia;

public class MysqlUtils {
	public static String LOGIN = "root";
	public static String SENHA = "rafaellange";
	public static String IP = "localhost";
	public static String PORTA = "3306";
	public static String NOME_BD = "integrador";

}
